import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class LocationService {

    public static String getLocationData() throws Exception {
        String apiUrl = "https://ipinfo.io/json";
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        // Parse JSON
        JSONObject json = new JSONObject(response.toString());

        String ip = json.optString("ip");
        String city = json.optString("city");
        String region = json.optString("region");
        String country = json.optString("country");
        String loc = json.optString("loc");
        String org = json.optString("org");

        return "IP Address: " + ip +
               "\nCity: " + city +
               "\nRegion: " + region +
               "\nCountry: " + country +
               "\nCoordinates: " + loc +
               "\nOrganization: " + org;
    }
}
