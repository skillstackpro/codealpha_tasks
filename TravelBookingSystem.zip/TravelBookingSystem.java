import javax.swing.*;
import java.awt.*;

public class TravelBookingSystem extends JFrame {

    private JTextArea outputArea;
    private JButton fetchButton;

    public TravelBookingSystem() {
        setTitle("Travel Booking System - IP Location Finder");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // UI Components
        fetchButton = new JButton("Fetch My Location");
        outputArea = new JTextArea();
        outputArea.setEditable(false);

        fetchButton.addActionListener(e -> {
            outputArea.setText("Fetching location...\n");
            try {
                String locationData = LocationService.getLocationData();
                outputArea.setText(locationData);
            } catch (Exception ex) {
                outputArea.setText("Error fetching location: " + ex.getMessage());
            }
        });

        // Layout
        setLayout(new BorderLayout());
        add(fetchButton, BorderLayout.NORTH);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TravelBookingSystem().setVisible(true);
        });
    }
}
