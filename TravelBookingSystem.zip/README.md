# Travel Booking System (IP Location Finder)

## Overview
This Java Swing application fetches and displays the user's location details based on their IP address using the `ipinfo.io` API.

## Features
- Fetch location data: IP, city, region, country, coordinates, ISP.
- Simple and clean Swing GUI.
- Uses `org.json` for JSON parsing.

## Requirements
- Java 8 or above
- `org.json` library (Download from https://mvnrepository.com/artifact/org.json/json)

## How to Run
1. Clone this repository:
   ```bash
   git clone <your-repo-link>
   ```
2. Add `json.jar` to your project classpath.
3. Compile and run:
   ```bash
   javac -cp .;json.jar TravelBookingSystem.java LocationService.java
   java -cp .;json.jar TravelBookingSystem
   ```

## API Reference
Data is fetched from [ipinfo.io](https://ipinfo.io/) free API.
